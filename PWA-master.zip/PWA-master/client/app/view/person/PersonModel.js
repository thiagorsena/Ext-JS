Ext.define('PWA.view.person.PersonModel', {
    extend: 'Ext.app.ViewModel',
    alias: 'viewmodel.person',

    data: {
        record: null
    }
});
